# This is a sample Python script.
import os
import re
import shutil
import subprocess
import string
import time


# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
work_path = os.getcwd()
now_file_path = work_path + "\\testfile.txt"
now_cpp_path = work_path + "\\testfile.cpp"
now_exe_path = work_path + "\\testfile.exe"
now_stdout_path = work_path + "\\stdout.txt"
now_compiler_path = work_path + "\\compile.txt"
now_mips_path = work_path + "\\mips.txt"
now_mips_run_path = work_path + "\\mips.asm"
now_input_forGcc_path = work_path + "\\input.txt"
now_input_forMars_path = work_path + "\\marsInput.txt"
testCase_path = work_path + "\\testcases"
output_path = work_path + "\\output"
count = 1
shutil.rmtree(output_path)
command = "mkdir " + output_path
os.system(command)

error_count = 0
accept_count = 0
re_count = 0
tle_count = 0
GlobalLog_Path = os.path.join(output_path, "log.txt")
GlobalLog = open(GlobalLog_Path, 'w', encoding="utf-8")

for root, dirs, files in os.walk(testCase_path):
    for file in files:
        if file.find("testfile") != -1:
            print("\033[33m 此为第" + str(count) + "次测试: \033[0m")
            print("\t查找到 " + os.path.join(root, file) + " 开始进行测试:")

            store_path = output_path + "\\testcase_" + str(count)
            store_file_path = store_path + "\\testfile.txt"
            store_cpp_path = store_path + "\\testfile.cpp"
            store_exe_path = store_path + "\\testfile.exe"
            store_stdout_path = store_path + "\\stdout.txt"
            store_compiler_path = store_path + "\\compile.txt"
            store_mips_path = store_path + "\\mips.txt"
            store_mips_run_path = store_path + "\\mips.asm"
            store_log_path = store_path + "\\log.txt"
            store_input_forGcc_path = store_path + "\\input.txt"
            store_input_forMars_path = store_path + "\\inputForMar.txt"

            origin_intput_name = re.sub(r'testfile', r'input', file)
            origin_intput_path = os.path.join(root, origin_intput_name)
            origin_file_path = os.path.join(root, file)
            originSource = open(origin_file_path, encoding='utf-8', errors='ignore').read()
            targetSource = re.sub('\\swhile\\s*\\((.*)\\)', r" for(;\1;)", originSource)
            # value = random.randint(5, 10)
            # targetSource = re.sub('getint.*?\\(\\)', str(value), targetSource)
            print("\t已经去除不符合文法的语句")
            with open(now_file_path, 'w', encoding="utf-8") as f:
                f.write(targetSource)
            getIntTemplate = open("getIntTemplate", encoding="utf-8").readlines()
            for i in range(len(getIntTemplate) - 1, -1, -1):
                targetSource = getIntTemplate[i] + targetSource
            targetSource = "#include<stdio.h>\n" + targetSource
            with open(now_cpp_path, 'w', encoding="utf-8") as f:
                f.write(targetSource)
            shutil.copy(origin_intput_path, now_input_forGcc_path)

            cpp = "testfile.cpp"
            exe = "testfile.exe"
            command = "gcc -o " + exe + " " + cpp
            max_try = 0
            while max_try < 3:
                process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
                process.communicate(timeout=10)
                if process.returncode != 0:
                    print("\t\033[93mGCC编译失败 第 " + str(max_try + 1) + " 次尝试\033[0m")
                    max_try += 1
                    time.sleep(3)
                else:
                    break
                    
            command = now_exe_path + " < " + now_input_forGcc_path + " > " + now_stdout_path
            os.system(command)

            command = "java -jar Compile.jar"

            max_try = 0
            while max_try < 3:
                process = subprocess.Popen(command.split(), stderr=subprocess.PIPE)
                try:
                    out, err = process.communicate(timeout=15)
                    dst = open("ErrorMessage.txt", 'w', encoding='utf-8')
                    dst.write(err.decode(encoding='utf-8', errors='ignore'))
                    dst.close()
                    break
                except subprocess.TimeoutExpired:
                    process.kill()
                    print("\t\033[36m编译中发生TimeOut! 第 " + str(max_try + 1) + " 次尝试\033[0m")
                    max_try += 1
                    time.sleep(3)

            if max_try == 3:
                tle_count += 1
                print("\t测试结果：\033[35m 编译中发生TimeOut! \033[0m \n")
                GlobalLog.write("TestCase_" + str(count) + ": " + "编译中发生TimeOut!\n")
                count = count + 1
                command = "mkdir " + store_path
                os.system(command)
                shutil.copy(now_file_path, store_file_path)
                shutil.copy(now_cpp_path, store_cpp_path)
                shutil.copy(now_exe_path, store_exe_path)
                shutil.copy(now_stdout_path, store_stdout_path)
                shutil.copy(now_input_forGcc_path, store_input_forGcc_path)
                continue

            ErrorContent = open("ErrorMessage.txt").readline()
            if len(ErrorContent) == 0:
                mips = open(now_mips_path).read()
                with open(now_mips_run_path, 'w', encoding="utf-8") as f:
                    f.write(mips)

                scan = open(now_input_forGcc_path, encoding="utf-8").read()
                result = re.split(' |\n|\t', scan)
                marsInput = open(now_input_forMars_path, 'w')
                for s in result:
                    if len(s) != 0:
                        marsInput.write(s + '\n')
                marsInput.close()

                command = "java -jar mars.jar mc Default nc mips.asm"
                max_try = 0
                while max_try < 3:
                    process = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
                    try:
                        marsScan = open(now_input_forMars_path, 'r').read()
                        out, err = process.communicate(input=marsScan.encode(encoding='utf-8', errors='ignore'), timeout=15)
                        dst = open(now_compiler_path, 'w', encoding="utf-8")
                        dst.write(out.decode(encoding='utf-8', errors='ignore'))
                        dst.close()
                        break
                    except subprocess.TimeoutExpired:
                        process.kill()
                        print("\t\033[36m执行汇编代码中TimeOut! 第 " + str(max_try + 1) + " 次尝试\033[0m")
                        max_try += 1
                        time.sleep(3)

                if max_try == 3:
                    tle_count += 1
                    print("\t测试结果：\033[35m 编译中发生TimeOut! \033[0m \n")
                    GlobalLog.write("TestCase_" + str(count) + ": " + "执行汇编代码中TimeOut!\n")
                    count = count + 1
                    command = "mkdir " + store_path
                    os.system(command)
                    shutil.copy(now_file_path, store_file_path)
                    shutil.copy(now_cpp_path, store_cpp_path)
                    shutil.copy(now_exe_path, store_exe_path)
                    shutil.copy(now_stdout_path, store_stdout_path)
                    shutil.copy(now_input_forGcc_path, store_input_forGcc_path)
                    shutil.copy(now_input_forMars_path, store_input_forMars_path)
                    shutil.copy(now_mips_path, store_mips_path)
                    shutil.copy(now_mips_run_path, store_mips_run_path)
                    continue

                command = "mkdir " + store_path
                os.system(command)
                shutil.copy(now_file_path, store_file_path)
                shutil.copy(now_cpp_path, store_cpp_path)
                shutil.copy(now_exe_path, store_exe_path)
                shutil.copy(now_stdout_path, store_stdout_path)
                shutil.copy(now_compiler_path, store_compiler_path)
                shutil.copy(now_mips_path, store_mips_path)
                shutil.copy(now_mips_run_path, store_mips_run_path)
                shutil.copy(now_input_forGcc_path, store_input_forGcc_path)
                shutil.copy(now_input_forMars_path, store_input_forMars_path)

                with open(now_stdout_path, 'r') as std:
                    std_content = std.readlines()
                with open(now_compiler_path, 'r') as test:
                    test_content = test.readlines()
                flag = 0
                if len(std_content) != len(test_content):
                    flag = 1
                else:
                    for i in range(len(std_content)):
                        if std_content[i] != test_content[i]:
                            flag = 1
                            break
                if flag:
                    error_count += 1
                    print("\t测试结果：\033[93m Wrong Answer! \033[0m \n")
                    GlobalLog.write("TestCase_" + str(count) + ": " + "Wrong Answer!\n")
                else:
                    accept_count += 1
                    print("\t测试结果：\033[92m Accepted! \033[0m \n")
                    GlobalLog.write("TestCase_" + str(count) + ": " + "Accepted!\n")
            else:
                re_count += 1
                print("\t测试结果： \033[94m Runtime Error! \033[0m ")
                print("\t\033[94m RE 信息已经输出到：" + store_log_path + " 中 \033[0m \n")
                GlobalLog.write("TestCase_" + str(count) + ": " + "Runtime Error!\n")
                command = "mkdir " + store_path
                os.system(command)
                shutil.copy(now_file_path, store_file_path)
                shutil.copy(now_cpp_path, store_cpp_path)
                shutil.copy(now_exe_path, store_exe_path)
                shutil.copy(now_stdout_path, store_stdout_path)
                shutil.copy("ErrorMessage.txt", store_log_path)
                shutil.copy(now_input_forGcc_path, store_input_forGcc_path)
            count = count + 1

print("\n\n\n")
print("----------------------测试结束----------------------")
print("\t\033[92m Accepted: " + str(accept_count) + "\033[0m")
print("\t\033[93m Wrong Answer: " + str(error_count) + "\033[0m")
print("\t\033[94m Runtime Error: " + str(re_count) + "\033[0m")
print("\t\033[35m TimeOut Error: " + str(tle_count) + "\033[0m")
print("\t\033[36m Total Test: " + str(count - 1) + "\033[0m")


