#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}//int getint(){}
void move(int x, int y)
{
	printf("%d->%d\n", x, y);
	return ;
}
void hanoi(int n, int a , int b , int c)
{
	if (n == 1)
	{
		move(a, c);
	}
	else
	{
		hanoi(n - 1, a, c, b);
		move(a, c);
		hanoi(n - 1, b, a, c);
	}
	return ;
}

int main()
{
	int n = 0;
	n = getint();;
	printf("21371119\n");
	hanoi(n,1,2,3);
	int fun1 = 0;
	printf("fun1:\n%d",fun1);
	return 0;
}
