#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}

const int ZERO = 0, ONE = 1;
int var2 = 2, var3 = 3;

void fun()
{
    int i = 1;
    {
        int yuming = 1;
        for (;yuming < 1000;)
        {
            /* code */
            yuming = yuming * 2;
        }
        printf("\n%d",yuming);
    }
    return;
}

int main()
{
    printf("21373457\n");
    if (ZERO + var2 == var3 - ONE && ONE)
    {
        if (ZERO || !ZERO && ONE + 1 + var2 < 0)
        {
            printf("ERROR!\n");
        }
        else
        {
            printf("And success!\n");
        }
    }

    if (var3 != 3 || var2 - 22 == -20)
    {

        if (ONE % 2 + 3 - 4 * 2 + var3 + var2 <= 100 || ONE)
        {
            printf("Or pass!\n");
        }
    }

    
    printf("Test1 Success!");
    {
    }
    fun();
    fun();
    fun();
    fun();
    fun();
    fun();
    
    return 0;
}