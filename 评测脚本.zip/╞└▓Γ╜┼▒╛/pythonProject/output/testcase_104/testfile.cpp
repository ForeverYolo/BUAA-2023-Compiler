#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}/**
 * this is test file 2
 */

const int constArray[5] = {1, 2, 3, 4 ,5};
const int a[2][2] = {{1, 0}, {0, 1}}, b[2][2] = {{0, 1}, {1, 0}};

void multi(int n1[][2], int n2[][2], int ans[][2]) {
    ans[0][0] = n1[0][0] * n2[0][0] + n1[0][1] * n2[1][0];
    ans[0][1] = n1[0][0] * n2[0][1] + n1[0][1] * n2[1][1];
    ans[1][0] = n1[1][0] * n2[0][0] + n1[1][1] * n2[1][0];
    ans[1][1] = n1[1][0] * n2[0][1] + n1[1][1] * n2[1][1];
}

void add(int n1[][2], int n2[][2], int ans[][2]) {
    ans[0][0] = n1[0][0] * n2[0][0];
    ans[0][1] = n1[0][1] * n2[0][1];
    ans[1][0] = n1[1][0] * n2[1][0];
    ans[1][1] = n1[1][1] * n2[1][1];
}

void copyConst(int dst[][2], int type) {
    if (type == 0) {
        dst[0][0] = a[0][0];
        dst[0][1] = a[0][1];
        dst[1][0] = a[1][0];
        dst[1][1] = a[1][1];
    } else {
        dst[0][0] = b[0][0];
        dst[0][1] = b[0][1];
        dst[1][0] = b[1][0];
        dst[1][1] = b[1][1];
    }
}

void copy(int dst[][2], int src[][2]) {
    dst[0][0] = src[0][0];
    dst[0][1] = src[0][1];
    dst[1][0] = src[1][0];
    dst[1][1] = src[1][1];
}

void getMat(int buffer[][2]) {
    buffer[0][0] = getint();
    buffer[0][1] = getint();
    buffer[1][0] = getint();
    buffer[1][1] = getint();
}

int main() {
    printf("19231111\n");
    int c[2][2] = {{1, 2}, {3, 4}}, d[constArray[1]][2], ans[2][2];
    copyConst(d, 1);
    add(c, d, ans);
    printf("%d %d %d %d\n", ans[0][0], ans[0][1], ans[1][0], ans[1][1]);
    copy(d, ans);
    printf("%d %d %d %d\n", d[0][0], d[0][1], d[1][0], d[1][1]);
    multi(c, d, ans);
    printf("%d %d %d %d\n", ans[0][0], ans[0][1], ans[1][0], ans[1][1]);
    getMat(d);
    multi(c, d, ans);
    printf("%d %d %d %d\n", ans[0][0], ans[0][1], ans[1][0], ans[1][1]);

    int arr1[1 + 5 * 0 - 9 / 9 + 56 / 8];
    arr1[6] = 5;
    printf("%d\n", arr1[6]);
    int arr2[2222 / 1111] = {1, 2};
    int i = 0;
    for(;i < 2;) {
        if (arr2[i] == constArray[i])
            printf("true\n");
        i = i + 1;
    }
    printf("%d\n", arr2[constArray[0]]);
    c[0][1] = 123;
    printf("%d\n", c[0][1]);
    c[0][0] = c[0][1];
    printf("%d\n", c[0][0]);
    return 0; // test
}
