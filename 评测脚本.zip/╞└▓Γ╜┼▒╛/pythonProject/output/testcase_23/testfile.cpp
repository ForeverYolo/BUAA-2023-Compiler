int a = 1;
int a;

int main() {
    return 0;
}