#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}int main() {
    printf("21371295\n");
    int i = 0;
    0 + 1;
    ;
    if (i > 0) {
        i = 1;
    } else {
        i = 0;
    }
    int a = 1, b = 2;
    if (a >= 0){
        a = 1;
    }
    if (a >= 0) {}
    if (!a) {
    } else {
    }
    if (b <= 0){
        b = 2;
    }
    if (a == b) {
        i = 1;
    }
    if (a != b) {
        i = 0;
    }
    if (a != b && a > 0) {
        i = 1;
    }
    if (a != b || a > 0) {
        i = 2;
    }

    a = a + 1 -3 * 4 / 3 % 2;
    a = 1 + 1;
    a = +-+1;

    return 0;
}