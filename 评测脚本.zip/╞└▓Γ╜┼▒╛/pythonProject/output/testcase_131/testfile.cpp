#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}// 编译单元
/* add exp



*/
//声明
const int const_a = 1;
const int const_a0 = 1 + 3, _const_a1 = 1 + 3 * 4 / 5 % 2;
int var_a;
int var_a0, var_a1;
int var_init = -1;
int var_init0 = -2 +-+5, var_init1 = 4 / 2;

//函数定义
void func_void0() {
    return;
}

void func_void1(int a1) {
    return;
}

void func_void2(int a1, int a2, int a3) {
    return;
}

int func_int0() {
    return 0;
}

int func_int1(int a1) {
    return 1;
}

int func_int2(int a1, int a2) {
    return 2;
}


// 主函数
int main() {
    printf("19373315\n");
    var_a = -const_a;
    var_a0 = (const_a + 1) * -5 * -1 % 7 + 1 -+-5;
    var_a1 = 1;
    int tmp_a = 0;
    int tmp_1 = 1;
    ;
    func_void0();
    1 + 1;
    {

    }
    {
        printf("this is a yu ju ky\n");
    }
    var_a = 1;
    for(;var_a <= 10;) {
        var_a = var_a + 1;
        if (var_a >= 8) {
            break;
        } else {
            continue;
        }
    }
    if (1) {
        if (1 == 1) {
            if (func_int0() == 0) {
                if (func_int1(1) == 1) {
                    if (func_int2(1, 2) - 5 +-1 != 1) {
                        if (1 < 2) {
                            if (2 > 1) {
                                printf("unbelievable!\n");
                            }
                        }
                    }
                }
            }
        }
    }
    if (!0) ;
    if (!func_int0()) ;
    if (2 - !func_int1(1) == 2) ;

    var_a = getint();
    printf("var_a from getint() is %d\n", var_a);
    printf("getint is %d\n", 1);
    printf("tmp\n");
    printf("tmp\n");
    printf("tmp\n");
    printf("tmp\n");
    printf("tmp\n");
    return 0;
}