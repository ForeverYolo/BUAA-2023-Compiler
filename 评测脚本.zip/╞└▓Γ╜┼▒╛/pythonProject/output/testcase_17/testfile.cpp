#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}void printMyID(int id)
{
    int i = 5;
 	for(;i >= 3;){
         printf("%d\n",id);
         i = i - 1;
    } 
    for(;i > 0;){
         printf("%d\n",id);
         i = i - 1;
    }       
    int j = 0;
    for(;j <= 3;){
         printf("%d\n",id);
         j = j + 1;
    }     
    for(;j < 5;){
         printf("%d\n",id);
         j = j + 1;
    }
	return;   
}

int playID(int id)
{
	int i = 0;
    for(;i < id;){
        i = i + 1;
        if(i == 711){
            continue;
        }
        if(i == 19182622){
            break;
        }
    }
    return i;
}
int block(){return 1;}

int main()
{
	const int id = 19182622;
	printMyID(id);
                for(;0;);
	return 0;
}