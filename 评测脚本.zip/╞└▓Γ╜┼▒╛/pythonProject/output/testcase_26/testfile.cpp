#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}const int a1 =1;
const int a2 = 2,a3 = 3;
const int a4 = 2,a5 = 3,a6 = 4;
const int b[2] = {0,1};
const int c[2][3] = {{0,0,1},{0,0,2}};

void test1(int a,int b) {
	return;
}

void test2() {
	return;
}

int test3(int a[],int b[][3]) {
	return 1;
}

int test4(int a,int b,int c) {
	return (a+b)*c;
}

void test5(int a,int b[],int c[][3]) {
	return;
}

int main() {
	printf("21373119");
	int a = 1;
	int xm = 0,xmm = 0;
	int yxm[2] = {1,0},yxmm[4][5], yxmmm;
	int b1[2] = {1,2};
	int c1[2][3] = {{1,2,3},{4,5,6}};
	{
		int a = 1;
		printf("%d\n",a); // 输出 1
	}
	{
		int x = 12;
		int y = 10;
		a = x * y;
		a = x / y;
		a = x % y + 2;
		a = x + y;
		a = x + y + (1 + 1);
		a = x - y;
		a = x * y * x / 2;
		a = (x + y) / x * 2;
		a = (x - y) * x + x % 7;

		a = 0;
		a = -1;
		a = +-+1;
		a = -+-1;
		;
		{
			
		}

		test1(a,a);
		test2();

		b1[1] = 1;
		c1[0][0] = 0;
		a = c1[0][0];
		a = b1[1];
		a = getint();
		test5(a,b1,c1);
		a = test3(b1,c1);
		a = test3(c1[0],c1);
		test4(a,b1[1],c1[0][0]);

		c1[1][1] = 1;
		if (x > y) {
			a = 1;
		}
		if (x >= y) {
			a = 2;
		}
		if (x <= y) {
			a = 3;
		}
		if (x > y + 1) {
			a = 4;
		}

		if (b1[1] == 1) {
			a = 5;
		} else {
			a = 6;
		}

		if (a != 1) {
			a = 7;
		}

		if (!0) {

		}

		for(;a == 1;) {
			a = 0;
			continue;
			break;
		}

		for(;!a;) {{
			break;
		}
		}
		
		{{
		}
		{
		}
		}

		{
			printf("%d%d",a,c1[1][1]);
		}
	}
	return 0;
}
