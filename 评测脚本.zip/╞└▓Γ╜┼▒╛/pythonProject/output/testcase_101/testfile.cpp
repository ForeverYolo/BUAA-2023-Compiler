#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}const int normal_const_1 = 114514;
const int normal_const_2 = 1919810;
const int normal_const_3 = 18, normal_const_4 = 37, normal_const_5 = 51, normal_const_6 = 82;
const int array_const_1[2] = {114514, 1919810};
const int array_const_2[2][2] = {{18, 37}, {51, 82}};

int normal_out_1 = 114514;
int normal_out_2 = 415411;
int normal_out_3 = 18, normal_out_4 = 37, normal_out_5 = 51, normal_out_6 = 82;
int normal_out_7;
int array_out_1[4];
int array_out_2[2][2];
int array_out_3[4] = {81, 73, 15, 28};
int array_out_4[2][2] = {{81, 73}, {15, 28}};

void do_nothing() {}

void do_nothing_but_return() {
	return;
}

int reverse_something(int to_be_reversed) {
	int reverse_finished = 0;
	int i;
 for(;to_be_reversed > 0;) {
		reverse_finished = reverse_finished * 10;
		i = to_be_reversed % 10;
		reverse_finished = reverse_finished + i;
		to_be_reversed = to_be_reversed / 10;
	}
	return reverse_finished;
} 

void reverse_all_and_printf(int normal, int array_1[], int array_2[][2]) {
	printf("%d", reverse_something(normal));
	int i = 0;
 for(;i < 4;) {
		printf("%d", reverse_something(array_1[i]));
		i = i + 1;
		continue;
	}
	int m = 2, n = 0;
 for(;m > 0;) {
	 for(;n < 2;) {
			printf("%d", reverse_something(array_2[2 - m][n]));
			n = n + 1;
		}
		n = 0;
		m = m - 1;
	}
}

int main() {
	int get_normal;
	get_normal = getint();
	printf("18375182");
	int normal_1;
	int normal_2;
	int normal_3;
	int normal_4;
	int array_1[4];
	int array_2[2][2];
	normal_1 = 18375182;
	normal_2 = reverse_something(normal_out_2);
	normal_3 = 0;
	normal_4 = 0;
	array_1[0] = 81;
	array_1[1] = 73;
	array_1[2] = 15;
	array_1[3] = 28;
	array_2[0][0] = 81;
	array_2[0][1] = 73;
	array_2[1][0] = 15;
	array_2[1][1] = 28;
	reverse_all_and_printf(array_1[0], array_out_3, array_out_4);
	if (1 == 1) ;
	normal_1 / normal_2;
	if (normal_2 == normal_1) {
		normal_3 = 189191;
	}else{
		normal_3 = 1919810;
	}
	if (normal_3 != normal_const_2) {
		normal_3 = 189191;
	}
	if(normal_3 > normal_2) {
		normal_3;
	} 
	if(normal_3 < normal_2) {
		normal_3;
	}
	if(normal_3 >= normal_2) {
		normal_3;
	}
	if(normal_3 <= normal_2) {
		normal_3;
	}
	if (!normal_4) {
		printf("18375182");
	}
	normal_2 / normal_3;
	normal_3 * 2;
	normal_2 % normal_3;
	(normal_2 % normal_3) + 1;
	-+normal_3;
	int i = 0;
 for(;i < 5;) {
		if (i == 2) {
			break;
		}
		i = i + 1;
	}
	return 0;
}



