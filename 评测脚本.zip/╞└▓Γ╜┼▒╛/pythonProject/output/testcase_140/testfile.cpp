#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}int aa(int b[][3])
{
    int w;
    w=b[0][0]+b[0][1]+b[0][2]+b[1][0]+b[1][1]+b[1][2];
    return w;
}
int main()
{
    printf("19182650\n");
    const int a[2][3]={{1,2,3},{4,5,6}};
    int b[2][3]={{1,2,3},{4,5,6}};
    int c[2][3];
    int d;
    d=aa(b);
    c[0][0]=b[0][0];
    c[0][1]=b[0][1];
    c[0][2]=b[0][2];
    c[1][0]=b[1][0];
    c[1][1]=b[1][1];
    c[1][2]=b[1][2];
    printf("%d\n",a[0][0]);
    printf("%d\n",a[0][1]);
    printf("%d\n",a[0][2]);
    printf("%d\n",a[1][0]);
    printf("%d\n",a[1][1]);
    printf("%d\n",a[1][2]);
    printf("%d\n",d);
    printf("%d\n",c[0][0]);
    printf("%d\n",c[1][2]);

    return 0;
}
