#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}/*  author: Hyggge, 
    email: hyggge6@gmail.com
*/

// #include<stdio.h>
// int getint(){
//    int n;
//    scanf("%d",&n);
//    return n;
// }

// const declare and define
const int _a = 0;
const int HelLo_World[5] = {1, 55, 0, 10, +9999};
const int a_r__r[2][2] = {{-1, 0}, {6, -555}};
const int _A = 6,
            B[1][1] = {{9966}}, 
            _ = 12, 
            c[1] = {555}, 
            __ = 4, 
            con_6[2][1] = {{0}, {6}};
const int lll = 1, rrr = 2;

const int awk_ = _A + _a + 5;
const int const_num = 1 + 5 - 1;
const int yyy[1 + 1][3] = {{1, 0, 2}, {-1, 3, -4}};

// variable declare
int var_1;
int var_2[100];
int var_3[2][12];
int varr_1, varr_2 = 10, varr_3[1 + 1], varr_4[5][999];

// variable define
int varrr_1 = 10;
int varrr_2[2] = {1, 2};
int varrr_3[2][0 + 2] = {{6, 6}, {-1, 0}};
int varrrr_1 = 666, varrrr_2, varrrr_3[5] = {1, 5, 1, 96, -5}, varrrr_4[1][2] = {{555, -5}};

// // function define
void func1(int a) {
    {_a + 1 + 2 - 1;}
    {
        int func1_var = 1;
        {
            int func1_var = 2;
            // printf("2_print: %dabcdefghighlmnopqrstuwvxyz//  /\n", func1_var);
        }
    }
    // printf("3_print:  !!! %d, %d, %d\n  ()*+-,-.//01234567879\n", a, a, a);
}


int func2(int a, int b[]) {
    // printf("4_print: %dAQWERTYUIOPLKJHGFDSAZXCVBNM%d\n", b[0], b[1]);
    ;;
    a = _A + 5 - 6;
    b[_A-6] = 46554646;
    if (a == 5) {
        // printf("5_print: a==    5\n");
    }

    if (a < 10) {
        a = 1000;
    } else {
        a = b[_A-5];
    }

    return 666;
}

void func3(int a[][3]) {
    int i = 0;

    if (a[_-12][0] > 10) {
        return;
    } else {
        // printf("6_print: hello wwwwwwwworld???????? %d\n", a[_-12][10]);
    }

    // printf("7_print: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! %d", i);

    for (;i < 100;) {
        if (i == 50)  {
            a[0][0] = 1;
            break;
            return; ; ;  ; ;;;
        } 
        else {
            i = i +1;
            continue;
        }
    }
}

int func4(int a, int b[], int  c[][3]) {
    a; b[0]; c[0][1];
    123456; 111111111;
    a + b[1] + c[0][0];
    -(1 + a)
    + (1 + a + 44 + (1 + 2));
    1 * 5 / 4 - 5 * 4 %4;
    + 6 * a;
    1 * 6; 8/444 + 6; 55/ 8; 5 * 9; 9% 44;
    return 999;
}

int func5() {
    if (1 == 2 || 2 != _a && 6666 + 5 == 4) {
        return 1111;
    } else if (! 666 != -_) {
        return 5464;
    } else if (__ <= 55 * var_3[1][1] || 2 >= 54564 || + 1 - + 2 == 6){
        return 4564665;
    } else if (1 || 1 < 2 + varrrr_2 || 8 > _a) {
        return 5456;
    } else {
        return 55555;
    }
    return -555;
}


int main() {
    // {};{};;;
    int arr[2][3] = {{1 * _a, 2*8, +3}, {123 - a_r__r[1][1], 5555 / varrrr_1, 0}};
    int bv[4] = {1/2, 6 * arr[0][0], 5555, 22 - 5 * 8 / 4 * 5 + 5 % 4};
    int a, b;
    a = getint();
    func1(varr_2);
    arr[1][2] = getint();
    func2(111, arr[1]);
    func3(arr);
    bv[1] = getint();
    func4(a, bv, arr);
    func5();
    // printf("8_print: %d    %d %d %d\n", -bv[0], +(bv[1] / 8), bv[2] + varrr_2[1], bv[3] + 5 -6);
    // printf("9_print: hello\n");
    // printf("10_print: world\n");
    printf("%d\n", 1);
    printf("%d\n", 1);
    printf("%d\n", 1);
    printf("%d\n", 1);
    printf("%d\n", 1);
    printf("%d\n", 1);
    printf("%d\n", 1);
    printf("%d\n", 1);
    printf("%d\n", 1);
    return 0;
}