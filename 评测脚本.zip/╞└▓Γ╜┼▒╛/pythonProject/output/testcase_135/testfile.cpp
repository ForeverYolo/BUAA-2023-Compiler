#include<stdio.h>
int getint() {
    int n;
    scanf("%d",&n);
    return n;
}const int a = 123, b = -234, c = 123 - 234;
const int x = 346, y = -13467, z = 12 * 12 * 153; 


int test_return2(int m, int n) {
	return 12;
}

int test_return1() {
	return (1 + 2 * 3);
}

int test_exp() {	//+-
	const int aaa = 1, bbb = 2, ccc = -123;
	int n = 0;
	int m = -(+(-(-(-123 % 24) * 9)/2)*84);
	n = (a + b * (c) + (1024 + x - z + y))% 1024;
	printf("n = %d\n", n);
	n = ((1024 * a) / +c * test_return1());
	printf("n = %d\n", n);
	n = (1234) % test_return2(12/2*bbb, 13 * 2 -6 / 3 + 5 % 2);
	printf("n = %d\n",n);
	n = +(-a + -b*+c) % ((-23));
	printf("n = %d\n", n);
	n = +-123 * (-test_return1());
	printf("n = %d\n", n);
	n = +0;	//+-
	printf("n = %d\n", n);
	(22+23 - 24 * 23 / +4) % 24;
	;
	
	return 0;
}

void test_constExp() {
	const int n = 324, m = 62445;
	const int p = +(x + a + -n) * 39;
	const int q = -(+(-(a)*b) % 49);
	const int i = (123 + (a) - -m / -23) % 12;
//	const int j = (-test_return1() + n - c + m - +y);
//	const int k = (test_return2(y, z) % 124);
	return ;
}

void test_if() {
	int a = 123;
	int bb = 0, cc = -1;
	if (a > 0) {
		if (a > 100) {
			bb = -123;
		} else {
			int edf_edf;
			edf_edf = test_return1();
		}
	}
	
	if (bb > 0) ;
	else if (bb == 0) {
		cc = 1;
	} else {
		cc = 0;
	}
	
	if (cc != 0) {
		//12345
	} else {
		int abc_abc = 123456;
	}
	;
	printf("test_if done!\n");
}

void test_while() {
	int i = 0, j = 0;
 for(;i < 10;)
		i = i + 1;
	i = 0;
 for(;i <= 10;) {
		i = i + 1;
	}
	
	i = 0;
 for(;i < 10;) {
		j = 0;
	 for(;j < 10;) {
			j = j + 1;
		}
		i = i + 1;
	}
	
 for(;j <= 0;) ;
	
	i = 10;
	j = 10;
	
 for(;i >= 0;) {
		j = 10;
	 for(;j > 0;) {
			j = j - 1;
		}
		i = i - 1;
	}
	
	printf("test_while done!\n");
	return ;
}

int test_if_while() {
	int i = 0, j = 0;
	int ret = 0;
	
 for(;i < 10;) {
		j = 0;
	 for(;j < 10;) {
			if (i * j > 50) ret = i * j;
			else ret = ret + i;
			j = j + 1;
		}
		i = i + 1;
	}
	
	if (ret > 0) {
	 for(;0;) ;
	} else {
	 for(;0;) ;
	}
	//printf("%d\n",ret);
	return ret;
}

void test_break_continue() {
	int i = 0, j = 0;
	
 for(;i < 20;) {
		j = 0;
	 for(;j < 20;) {
			if (i == 10) break;
			j = j + 1;
		}
		i = i + 1;
	}
	
	i = 0;
	j = 0;
	
 for(;i < 20;) {
		j = 0;
	 for(;j < 20;) {
			if (j == 0) {
				j = j + 1;
				continue;
			}
			j = j + 1;
		}
		i = i + 1;
	}
	
	printf("test_break_continue done!\n");
}



int main() {
	int x_x;
	x_x =  getint();
	printf("19373755\n");
	test_exp();
	test_if();
	test_while();
	test_if_while();
	test_break_continue();
	
	return 0;
}